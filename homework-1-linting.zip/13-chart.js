(function() {
  d3.csv("eating-data.csv").then(ready)
    .catch(function(err) {
      console.log("Failed with", err)
    })

  var margin = {
    top: 10,
    right: 10,
    bottom: 10,
    left: 10
  }

  var width = 600 - margin.left - margin.right
  var height = 700 - margin.top - margin.bottom

  var svg = d3.select("#chart13")
    .attr("width", width)
    .attr("height", height)
    .attr("transform", "translate(25, 25)")

  //var names = datapoints.map(function(d) {
    //return d.name 
  //})

// Build your scales here
  const scaleBand = d3
    .domain(['Stevie', 'Nicholas', 'Bubbletree','Particle','Jumpup','Parlay','Hio'])
    .range([0, 400])

  const widthScale = d3
    .scaleLinear()
    .domain([0,10])
    .range([0,500])

  const colorScale = d3
    .scaleOrdinal()
    .range(['blue','red', 'green'])

  function ready(datapoints) {
    console.log('Data is', datapoints)


    svg.select('#chart13')
      .selectAll('rect')
      .data(datapoints)
      .enter()
      .append('rect')
      .attr('y',function(d) {
        return scaleBand(d.name)
        })
      .attr('height', 50)
      .attr('width', function(d) {
        return d.hamburgers;
        })
      .attr('opacity', .50)
      .attr('fill', 'blue')
      }
})()




    //Axis stuff:
    var xAxis = d3
      .axisBottom(pointScale)
      .ticks(10)

     svg
      .append('g')
      .attr('class', 'axis x-axis')
      .attr('transform', 'translate(100,' + 400 + ')')
      .call(xAxis)
      .lower()

    //svg
      //.append('text')
      //.attr("x", 240 )
      //.attr("y", 640 )
      //.text("hamburgers consumed")


    var yAxis = d3
      .axisLeft(pointScale)
      .ticks(5)

    svg
      .append('g')
      .attr('class', 'axis y-axis')
      .attr('transform', 'translate(100,0)')
      .call(yAxis)
 